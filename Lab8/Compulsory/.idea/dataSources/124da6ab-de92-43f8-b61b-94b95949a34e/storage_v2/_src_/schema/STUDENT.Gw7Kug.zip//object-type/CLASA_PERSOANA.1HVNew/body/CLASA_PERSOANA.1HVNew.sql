create TYPE BODY clasa_persoana AS
    -- constructor explicit
    CONSTRUCTOR FUNCTION clasa_persoana(nume varchar2, prenume varchar2, cnp varchar2, telefon varchar2, email varchar2)
        RETURN SELF AS RESULT
        AS
        BEGIN

            RETURN;
        END;
END;
/

