create TYPE clasa_persoana AS OBJECT
(nume varchar2(32), prenume varchar2(32), CNP VARCHAR2(14), telefon VARCHAR2(10), email VARCHAR2(32),
 member procedure informatiiPersoana(cnp varchar2),
 member procedure save,
 CONSTRUCTOR FUNCTION persoana(nume varchar2)
     RETURN SELF AS RESULT,
 CONSTRUCTOR FUNCTION persoana(nume varchar2, prenume varchar2, cnp varchar2, telefon varchar2, email varchar2)
     RETURN SELF AS RESULT
) NOT FINAL;
/

